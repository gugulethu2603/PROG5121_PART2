/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp;
import javax.swing.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author 50324
 */
public class QuickChatApp {
    
        // Variable to hold user's details
    static String userName;
    static String passWord;
    static String phoneRegistered;
    
    
    static int totalMessageSent = 0;
    static int numberOfMessages = 0;

    // Program to display a welcome message
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
        registerUser(); // Run registration first
        
        // Check if login details are correct selecting other options
        if (loginUser()) {
            JOptionPane.showMessageDialog(null, "Access Granted! Redirecting to QuickChat.....");
            messageHub();
        } else {
            JOptionPane.showMessageDialog(null, "Access Denied! Exit App");
        }
    }

    // Validate input sign up, user to enter username with five characters and underscore
    public static void registerUser() {
        boolean valid = false;

        while (!valid) {
            // Username check: must have an underscore and be 5 chars or less
            userName = JOptionPane.showInputDialog(null, "Create a username (must contain _ and max 5 chars):");
            if (userName == null || !(userName.contains("_") && userName.length() <= 5)) {
                JOptionPane.showMessageDialog(null, "Invalid username.");
                continue;
            }

            // Password check: needs 8+ chars, 1 uppercase, 1 digit, and 1 special character
            passWord = JOptionPane.showInputDialog(null, "Create Password(8+char, 1Uppercase, 1 digit and a special character):");
            if (passWord == null || !passWord.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$5^&+=!]).{8,}$")) {
                JOptionPane.showMessageDialog(null, "Invalid password.");
                continue;
            }

            // Phone check: must match South African format starting with +27
            phoneRegistered = JOptionPane.showInputDialog(null, "Enter Phone number(+27-- --- ----):");
            if (phoneRegistered == null || !phoneRegistered.matches("^\\+27[6-8]\\d{8}$")) {
                JOptionPane.showMessageDialog(null, "Invalid Phone number");
                continue;
            }
            
            JOptionPane.showMessageDialog(null, "Registration Successful!");
            valid = true; // Breaks the loop if everything passes
        }
    }

    // Ask user for login and checks against registered information provided when registering
    public static boolean loginUser() {
        String user = JOptionPane.showInputDialog("Enter your username:");
        String pass = JOptionPane.showInputDialog("Enter your password:");

        if (user == null || pass == null) return false;
        return user.equals(userName) && pass.equals(passWord);
    }

    // Displays the main navigation menu
    public static void messageHub() {
        boolean loopActive = true;

        while (loopActive) {
            String[] options = {"Send Messages", "Coming Soon", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an Option:", "Main Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options);

            switch (choice) {
                case 0 -> sendMessages(); // Go to message sender
                case 1 -> JOptionPane.showMessageDialog(null, "Coming Soon."); 
                case 2 -> {
                    loopActive = false;
                    JOptionPane.showMessageDialog(null, "Goodbye!"); 
                }
            }
        }
    }

    // Creates an input where user specifies how many message they would lie to send.
    public static void sendMessages() {
        String countInput = JOptionPane.showInputDialog("How many messages would you like to send?");
        if (countInput == null) return;
        
        int count = Integer.parseInt(countInput);

        for (int i = 0; i < count; i++) {
            numberOfMessages++;
            String messageID = generateMessageID();

            // Check if recipient number is formatted correctly
            String recipient = JOptionPane.showInputDialog("Enter the recipient number(+27-- --- ----)");
            if (recipient == null || !recipient.matches("^\\+27[6-8]\\d{8}$")) {
                JOptionPane.showMessageDialog(null, "Invalid number format.");
                i--; // Step back so user can retry this specific message iteration
                continue;
            }

            // Check if text exceeds the 250 character limit
            String message = JOptionPane.showInputDialog("Enter your message(max 250 characters):");
            if (message == null || message.length() > 250) {
                JOptionPane.showMessageDialog(null, "Message too long or empty.");
                i--; // Step back to retry
                continue;
            }
            
            String hash = generateMessageHash(messageID, numberOfMessages, message);
            String[] actions = {"Send", "Disregard", "Store"};
            int action = JOptionPane.showOptionDialog(null, "What do you want to do?", "Message Options",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, actions, actions);

            switch (action) {
                case 0 -> {
                    totalMessageSent++;
                    displayMessageDetails(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message successfully sent.");
                }
                case 1 -> JOptionPane.showMessageDialog(null, "Message disregarded");
                case 2 -> {
                    writeMessageToJSON(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message stored");
                }
            }
        }

        JOptionPane.showMessageDialog(null, "Total Message Sent:" + totalMessageSent);
    }

    // Creates a random 10-digit number for the message ID
    public static String generateMessageID() {
        return String.format("%10d", new Random().nextInt(1_000_000_000));
    }

    // Generates a short tracking code/hash using the message contents
    public static String generateMessageHash(String id, int num, String msg) {
        // Cut off extra outside spaces and split the message into words by spaces
        String[] words = msg.trim().split("\\s+");
        
        // Grab the first word from the array
        String first = words[0];
        
        // Grab the last word from the array
        String last = words[words.length - 1];
        
        // Combine first 2 digits of ID, current count, and the words, then make it uppercase
        return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
    }

    // Popup showing message details
    public static void displayMessageDetails(String id, String hash, String recipient, String message) {
        JOptionPane.showMessageDialog(null, "Message ID:" + id + "\nHash: " + hash
                + "\nRecipient:" + recipient + "\nMessage: " + message);
    }

    // Appends message data into a local text file structured as JSON
    public static void writeMessageToJSON(String messageID, String hash, String recipient, String message) {
        StringBuilder jsonEntry = new StringBuilder();
        jsonEntry.append("{\n");
        jsonEntry.append(" \"MessageID\": \"").append(messageID).append("\",\n");
        jsonEntry.append(" \"MessageHash\": \"").append(hash).append("\",\n");
        jsonEntry.append(" \"Recipient\": \"").append(recipient).append("\",\n");
        // Escape quotation marks inside the user's message text to keep JSON valid
        jsonEntry.append(" \"Message\": \"").append(message.replace("\"", "\\\"")).append("\" \n");
        jsonEntry.append("}\n");

        // Open file writer in append mode and auto-close when done
        try (FileWriter file = new FileWriter("Jsonnew.json", true)) {
            file.write(jsonEntry.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file: " + e.getMessage());
        }
    }
}



        

        
        
        

        
        
        
        
    
     
     
        
    


